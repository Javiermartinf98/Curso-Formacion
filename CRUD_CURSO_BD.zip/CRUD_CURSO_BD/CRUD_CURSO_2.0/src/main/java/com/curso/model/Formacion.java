package com.curso.model;

public class Formacion 
{
	private String curso;
	private int asignaturass;
	private double precio;
	
	public Formacion(){ }

	public Formacion(String curso, int asignaturass, double precio) 
	{
		super();
		this.curso = curso;
		this.asignaturass = asignaturass;
		this.precio = precio;
	}

	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso)
	{
		this.curso = curso;
	}

	public int getAsignaturass() {
		return asignaturass;
	}
	public void setAsignaturass(int asignaturass) {
		this.asignaturass = asignaturass;
	}

	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
}
