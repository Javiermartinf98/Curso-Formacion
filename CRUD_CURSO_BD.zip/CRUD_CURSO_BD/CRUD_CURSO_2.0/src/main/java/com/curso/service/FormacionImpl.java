package com.curso.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.curso.model.Curso;
import com.curso.model.Formacion;

@Service
public class FormacionImpl implements FormacionService
{
	@Autowired
	RestTemplate template;
	
	String url="http://localhost:8500/";
	
	List<Formacion> misformaciones = new ArrayList<>();
	@Override
	public List<Formacion> formaciones() 
	{
		for(Curso c :Arrays.asList(template.getForObject(url+"cursos", Curso[].class)))
		{
			if(c.getDuracion() >= 50)
			{
				misformaciones.add(new Formacion(c.getNombre(),10,c.getPrecio()));
			}
			else
			{
				misformaciones.add(new Formacion(c.getNombre(),5,c.getPrecio()));
			}
		}
		return misformaciones;
	}
	
	public void AltaCurso(Curso c)
	{
		//busco en el arraylist de formacion
		for(Formacion formacion : misformaciones)
		{
			//si nombre curso de la formacion es distinto o igual que el nombre del cusrp
			if(!formacion.getCurso().equals(c.getNombre())) 
			{
				//se modifica la duracion de la asignatura
				c.setDuracion(formacion.getAsignaturass()*10);
				template.postForLocation(url+"curso", c);
			}
		}
	}
}
