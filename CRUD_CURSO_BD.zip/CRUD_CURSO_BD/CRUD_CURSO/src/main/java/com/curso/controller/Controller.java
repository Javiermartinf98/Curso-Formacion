package com.curso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Curso;
import com.curso.service.CursoService;

@RestController
public class Controller 
{
	@Autowired
	CursoService service;
	
	//http://localhost:8500/curso
	@PostMapping(value="cursos", consumes= MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> AltaCurso(@RequestBody Curso c)
	{
		return service.AltaCurso(c);
	}
	
	//http:localhost:8500/curso/{codcurso}
	@DeleteMapping(value="curso/{codcurso}", consumes= MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> EliminarCurso(@PathVariable int codcurso)
	{
		return service.EliminarCurso(codcurso);
	}
	
	//http://localhost:8500/cursos
	@GetMapping(value="cursos", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> cursos()
	{
		return service.cursos();
	}
	
	//http://localhost:8500/curso/{min}&{max}
	@GetMapping(value="curso/{min}&{max}", produces= MediaType.APPLICATION_JSON_VALUE)
	public List<Curso> cursosXPrecios(@PathVariable("min") double min, @PathVariable("max") double max)
	{
		return service.cursosXPrecios(min, max);
	}
	
	@PutMapping(value="curso/{codcurso}/{duracion}", consumes=MediaType.APPLICATION_JSON_VALUE)
	public void actualizarCurso(@PathVariable("codcurso") int codcurso,@PathVariable("duracion") int duracion)
	{
		service.actualizarCurso(codcurso, duracion);
	}

}
